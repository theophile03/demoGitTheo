var films = [
    {    name: "Deadpool",    years: 2016,    authors : "Tim Miller" },
    {    name: "Spiderman",    years: 2002,    authors : "Sam Raimi" },
    {    name: "Scream",    years: 1996,    authors : "Wes Craven" },
    {    name: "It: chapter 1",    years: 2019,    authors : "Andy Muschietti" }
];

// TODO